from django.apps import AppConfig


class FirebaseAlertConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'firebase_alert'
